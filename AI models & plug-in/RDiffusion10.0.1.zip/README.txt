Hey! Thanks for downloading Retro Diffusion.

Installation video: https://youtu.be/W0ONTeY_tVc
Written guide: https://astropulse.gitbook.io/retro-diffusion/aseprite-extension/retro-diffusion-for-aseprite/installation-and-setup

To properly install this extension, open Aseprite, then navigate to Edit -> Preferences -> Extensions -> Add Extension, and select the "RetroDiffusion.aseprite-extension" file.

The script to get started can be found inside Aseprite in File -> Setup Stable Diffusion Environment.

(Antivirus may flag it as malicious, since it attempts to use CMD. I can assure you it is safe, you are also welcome to check the code yourself.)

AI generation scripts are located in Aseprite under Sprite -> Text to Image/Image to Image.

Help tips can be found inside script GUI's and in Aseprite under File -> Retro Diffusion Help.

PLEASE READ ALL INSTRUCTIONS CAREFULLY! I did my best to make the setup process easy, but machine learning is still a complex thing to get running with no troubleshooting.

If you encounter issues, go though the setup again and restart your computer.

If issues persist, please add me on Discord: astropulse, or contact via email: support@astropulse.co